const setCatalog = index => ({
	type: "SET_CATALOG",
	catalogIndex: index,
});

export { setCatalog };
